package com.example.floatingmenudemo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setBackgroundColor(0xFF101116);

        TextView title = new TextView(this);
        title.setText("FLOATING MENU DEMO");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(22);
        title.setPadding(0, 0, 0, 24);
        layout.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Разреши отображение поверх других приложений, затем запусти плавающее меню. Переключатели демонстрационные.");
        desc.setTextColor(0xFFCCCCD6);
        desc.setTextSize(16);
        desc.setPadding(0, 0, 0, 24);
        layout.addView(desc);

        Button start = new Button(this);
        start.setText("Разрешение / Запустить меню");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else {
                startService(new Intent(this, OverlayService.class));
                finish();
            }
        });
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Закрыть плавающее меню");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        layout.addView(stop);
        setContentView(layout);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
            finish();
        }
    }
}
