package com.example.floatingmenudemo;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private boolean esp = false, aim = false, magic = false, bullet = false, info = false;
    private TextView status;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildPanel();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(1, 0xFF343746);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private void buildPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 14, 18, 14);
        box.setBackground(bg(0xF0191B24, 24));

        TextView header = text("  MENU  /  DEMO       ⠿", 18, Color.WHITE);
        header.setPadding(4, 8, 4, 14);
        header.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    touchX = e.getRawX(); touchY = e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - touchX);
                    params.y = startY + (int)(e.getRawY() - touchY);
                    wm.updateViewLayout(panel, params); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
        box.addView(header);
        View line = new View(this);
        line.setBackgroundColor(0xFF3B3E4D);
        box.addView(line, new LinearLayout.LayoutParams(-1, 1));

        addToggle(box, "ESP display", 0);
        addToggle(box, "Aim option", 1);
        addToggle(box, "Magic option", 2);
        addToggle(box, "Bullet option", 3);
        addToggle(box, "Extra information", 4);

        status = text("Демо: функции не подключены к игре", 11, 0xFF9EA4B8);
        status.setPadding(2, 8, 2, 8);
        box.addView(status);

        Button hide = new Button(this);
        hide.setText("Свернуть");
        hide.setAllCaps(false);
        hide.setOnClickListener(v -> {
            if (panel != null) { wm.removeView(panel); panel = null; }
            stopSelf();
        });
        box.addView(hide);

        panel = box;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 24; params.y = 120;
        wm.addView(panel, params);
    }

    private void addToggle(LinearLayout parent, String label, int id) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(8, 5, 8, 5);
        row.setBackground(bg(0xFF242733, 14));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(0, 7, 0, 0);
        TextView name = text(label, 14, 0xFFF2F3F8);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView value = text("OFF", 13, 0xFFFF7B83);
        value.setPadding(12, 4, 4, 4);
        row.addView(value);
        row.setOnClickListener(v -> {
            boolean on;
            switch (id) {
                case 0: esp = !esp; on = esp; break;
                case 1: aim = !aim; on = aim; break;
                case 2: magic = !magic; on = magic; break;
                case 3: bullet = !bullet; on = bullet; break;
                default: info = !info; on = info; break;
            }
            value.setText(on ? "ON" : "OFF");
            value.setTextColor(on ? 0xFF7DF0B1 : 0xFFFF7B83);
            row.setBackground(bg(on ? 0xFF233B36 : 0xFF242733, 14));
            if (status != null && id == 4) status.setText(on ?
                "Доп. информация включена (демо)" : "Демо: функции не подключены к игре");
        });
        parent.addView(row, rp);
    }

    @Override public void onDestroy() {
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        super.onDestroy();
    }
}
